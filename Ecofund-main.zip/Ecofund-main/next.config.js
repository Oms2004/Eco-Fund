module.exports = {
    reactStrictMode: true,
    images: {
      domains: ["localhost"], // Allow local image loading
    },
    staticPageGenerationTimeout: 300,
 };
  